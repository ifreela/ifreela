=== Fashify ===

Fashify Theme, Copyright 2017 FameThemes
Fashify is distributed under the terms of the GNU GPL

== Description ==

A fashionable WordPress blog theme.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
* Font Awesome License, SIL OFL 1.1. (http://scripts.sil.org/OFL) http://fontawesome.io/license/
* Font Awesome Code License, MIT. http://opensource.org/licenses/mit-license.html
* Image use in screenshot: https://www.pexels.com/photo/desk-coffee-chemex-phone-laptop-6599/. [CC0](https://creativecommons.org/publicdomain/zero/1.0/)

== Changelog ==

= 0.0.8 =
* Hide home layout settings to improve in next version.
* Update screenshot and change theme URI.
* Update theme author URI.
